const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6285930467004'
global.versi = "V5"
global.namaOwner = "⏤͟͟͞͞𝐋𝐞𝐱𝐳𝐲 𝐦𝐚𝐫𝐤𝐞𝐭"
global.packname = '⏤͟͟͞͞𝐋𝐞𝐱𝐳𝐲 𝐦𝐚𝐫𝐤𝐞𝐭'
global.botname = '⏤͟͟͞͞𝐋𝐞𝐱𝐳𝐲𝐦𝐚𝐫𝐤𝐞𝐭'
global.botname2 = '𝐋𝐞𝐱𝐳𝐲 𝐦𝐚𝐫𝐤𝐞𝐭'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6285930467004"
global.linkGrup = ""
//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 1000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029VbB2wFrI1rcovTbVQw16"
global.idSaluran = "120363416262862080@newsletter"
global.namaSaluran = "SALURAN || MANG LEXZY"
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.payment = "ALL PAYMENT? KETIK PAY"
global.dana = "083892079899"
global.qris = "https://files.catbox.moe/krelrz.jpg"
global.gopay = "085930467004"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://files.catbox.moe/tr51xx.jpg", 
reply: "https://files.catbox.moe/tr51xx.jpg", 
logo: "https://files.catbox.moe/tr51xx.jpg", 
qris: "https://files.catbox.moe/krelrz.jpg"
}
//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya Untuk Owner",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})